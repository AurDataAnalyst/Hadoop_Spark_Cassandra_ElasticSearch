#!/bin/bash

# ce script permet de lancer des requêtes sur Elasticsearch


## Configuration générale

# configuration
HOST=hadoop
SERVEUR=http://$HOST:9200
INDEX="${SERVEUR}/${LOGNAME}-livres"


# alias et fonctions diverses
shopt -s expand_aliases
alias curljson='curl -H "Content-Type: application/json" -d @-'
function titre() {
    echo -e "\n$(tput bold)$*$(tput sgr0)"
}

titre "URL de base de cet index: ${INDEX}"


## Définitions des fonctions

function schema() {
    titre "création de l'index ${INDEX}"
    curljson -X PUT "${INDEX}?include_type_name=true&pretty" <<JSON
    {
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0
        },
        "mappings": {
            "livre": {
                "properties": {
                    "categorie":    { "type": "keyword" }
                }
            }
        }
    }
JSON
    titre "Ouvrir l'URL ${INDEX}?pretty pour vérifier le schéma"
}


function donnees() {
    titre "ajout des données dans l'index"
    sed 's/"livres"/"'${LOGNAME}'-livres"/' livres.ndjson | curl -H "Content-Type: application/x-ndjson" -XPOST "${SERVEUR}/_bulk?pretty" --data-binary @-
    titre "Ouvrir l'URL ${INDEX}/_search?pretty pour vérifier les données"
}


function deleteall() {
    titre "suppression de l'index ${LOGNAME}-livres"
    curl -X DELETE "${INDEX}?pretty"
}


# Exercices


function exo_6_1() {
    titre "livres parus entre 1850 et 1900"
}


function exo_6_2() {
    titre "livres parus entre 1850 et 1900"
}


function exo_6_3() {
    titre "livres humour comique"
}


## Appels des fonctions voulues

# commenter les fonctions qu'il ne faut pas appeler, selon ce que vous faites

# créer le schéma et les données
#deleteall
schema
#donnees

# exercices
#exo_6_1
#exo_6_2
#exo_6_3



# tout supprimer
#deleteall

