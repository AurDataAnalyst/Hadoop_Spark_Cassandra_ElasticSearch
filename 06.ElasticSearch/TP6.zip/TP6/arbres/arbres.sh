#!/bin/bash

# ce script permet de lancer des requêtes sur Elasticsearch


## Configuration générale

# configuration
HOST=hadoop
SERVEUR=http://$HOST:9200
INDEX="${SERVEUR}/${LOGNAME}-arbres"


# alias et fonctions diverses
shopt -s expand_aliases
alias curljson='curl -H "Content-Type: application/json" -d @-'
function titre() {
    echo -e "\n$(tput bold)$*$(tput sgr0)"
}

titre "URL de base de cet index: ${INDEX}"


## Définitions des fonctions

function schema() {
    titre "création de l'index ${INDEX}"
    curljson -X PUT "${INDEX}?include_type_name=true&pretty" <<JSON
    {
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 0
        },
        "mappings": {
            "arbre": {
                "properties": {
                    "genre":            { "type": "text" },
                    "variete":          { "type": "keyword" },
                    "geopoint":         { "type": "geo_point" },
                    "adresse":          {
                        "properties": {
                            "arrondissement": { "type": "integer" },
                            "lieu":           { "type": "keyword" }
                        }
                    },
                    "objectid":         { "type": "integer" }
                }
            }
        }
    }
JSON
    titre "Ouvrir l'URL ${INDEX}?pretty pour vérifier le schéma"
}


function donnees() {
    titre "ajout des données dans l'index"
    ./csv2ndjson.py -i "${LOGNAME}-arbres" -t arbre arbres_tp6.csv | curl -H "Content-Type: application/x-ndjson" -XPOST "${SERVEUR}/_bulk?pretty" --data-binary @-
    titre "Ouvrir l'URL ${INDEX}/_search?pretty pour vérifier les données"
}


function deleteall() {
    titre "suppression de l'index ${LOGNAME}-arbres"
    curl -X DELETE "${INDEX}?pretty"
}


function get1() {
    titre "récupération arbre id 1"
    curl -X GET "${INDEX}/arbre/1?pretty"
}


# Partie 3 : requêtes dans l'URL

function recherche_url() {
    titre "recherche arbres genre Acer par l'URL"
    Q='genre:Acer'
    curl --get "${INDEX}/_search" --data-urlencode "q=${Q}" --data-urlencode "pretty"
    titre "Ouvrir l'URL ${INDEX}/_search?pretty&q=${Q}"
}


function exo_3_1() {
    titre "arbres du 5e"
    Q='genre:Acer'
    curl --get "${INDEX}/_search" --data-urlencode "q=${Q}" --data-urlencode "pretty"
    titre "Ouvrir l'URL ${INDEX}/_search?pretty&q=${Q}"
}


function exo_3_2() {
    titre "arbres nom commun contient Erable"
    Q='genre:Acer'
    curl --get "${INDEX}/_search" --data-urlencode "q=${Q}" --data-urlencode "pretty"
    titre "Ouvrir l'URL ${INDEX}/_search?pretty&q=${Q}"
}


function exo_3_3() {
    titre "arbres nom commun est Erable de Montpellier"
    Q='genre:Acer'
    curl --get "${INDEX}/_search" --data-urlencode "q=${Q}" --data-urlencode "pretty"
    titre "Ouvrir l'URL ${INDEX}/_search?pretty&q=${Q}"
}


function exo_3_4() {
    titre "arbres nom commun contient Erable et Montpellier"
    Q='genre:Acer'
    curl --get "${INDEX}/_search" --data-urlencode "q=${Q}" --data-urlencode "pretty"
    titre "Ouvrir l'URL ${INDEX}/_search?pretty&q=${Q}"
}


function exo_3_5() {
    titre "arbres hauteur sup ou égale à 40 m"
    Q='genre:Acer'
    curl --get "${INDEX}/_search" --data-urlencode "q=${Q}" --data-urlencode "pretty"
    titre "Ouvrir l'URL ${INDEX}/_search?pretty&q=${Q}"
}


function exo_3_6() {
    titre "arbres du Bois de Vincennes plantés avant 1850 plantés avant 1850"
    Q='genre:Acer'
    curl --get "${INDEX}/_search" --data-urlencode "q=${Q}" --data-urlencode "pretty"
    titre "Ouvrir l'URL ${INDEX}/_search?pretty&q=${Q}"
}


function exo_3_7() {
    titre "arbres du 18e siècle"
    Q='genre:Acer'
    curl --get "${INDEX}/_search" --data-urlencode "q=${Q}" --data-urlencode "pretty"
    titre "Ouvrir l'URL ${INDEX}/_search?pretty&q=${Q}"
}


# Partie 4 : requêtes DSL (JSON)


function recherche_dsl() {
    titre "recherche arbres genre Acer avec DSL"
    curljson -X GET "${INDEX}/_search?pretty" <<JSON
    {
      "query": {
        "match": {
          "genre": "Acer"
        }
      }
    }
JSON
}


function exo_4_1() {
    titre "arbres de plus de 40m"
    curljson -X GET "${INDEX}/_search?pretty" <<JSON
    {
      "query": {
        "match": {
          "genre": "Acer"
        }
      }
    }
JSON
}


function exo_4_2() {
    titre "arbres nom commun contient Erable"
    curljson -X GET "${INDEX}/_search?pretty" <<JSON
    {
      "query": {
        "match": {
          "genre": "Acer"
        }
      }
    }
JSON
}


function exo_4_3() {
    titre "arbres nom commun contient Erable et Montpellier"
    curljson -X GET "${INDEX}/_search?pretty" <<JSON
    {
      "query": {
        "match": {
          "genre": "Acer"
        }
      }
    }
JSON
}


function exo_4_4() {
    titre "arbres nom commun Platane pas commun situé dans le 12e"
    curljson -X GET "${INDEX}/_search?pretty" <<JSON
    {
      "query": {
        "match": {
          "genre": "Acer"
        }
      }
    }
JSON
}


function exo_4_5() {
    titre "arbres nom commun contient uniquement Erable et Montpellier"
    curljson -X GET "${INDEX}/_search?pretty" <<JSON
    {
      "query": {
        "match": {
          "genre": "Acer"
        }
      }
    }
JSON
}



function exo_4_6() {
    titre "séquoia géants du bois de boulogne et parc montsouris"
    curljson -X GET "${INDEX}/_search?pretty" <<JSON
    {
      "query": {
        "match": {
          "genre": "Acer"
        }
      }
    }
JSON
}


# Partie 5 : agrégations DSL


function agregation_dsl() {
    titre "hauteur moyenne des arbres"
    curljson -X GET "${INDEX}/_search?size=0&pretty" <<JSON
    {
        "aggs": {
            "hauteur moyenne": {
                "avg": {
                    "field": "hauteur"
                }
            }
        }
    }
JSON
}


function exo_5_1() {
    titre "année du plus vieil arbre"
    curljson -X GET "${INDEX}/_search?size=0&pretty" <<JSON
    {
        "aggs": {
            "hauteur moyenne": {
                "avg": {
                    "field": "hauteur"
                }
            }
        }
    }
JSON
}


function exo_5_2() {
    titre "lieux possédant des arbres"
    curljson -X GET "${INDEX}/_search?size=0&pretty" <<JSON
    {
        "aggs": {
            "hauteur moyenne": {
                "avg": {
                    "field": "hauteur"
                }
            }
        }
    }
JSON
}





## Appels des fonctions voulues

# commenter les fonctions qu'il ne faut pas appeler, selon ce que vous faites

# créer le schéma et les données
#deleteall
schema
#donnees

# tutoriel
#get1
#recherche_url
#recherche_dsl
#agregation_dsl

# exercices
#exo_3_1
#exo_3_2
#exo_3_3
#exo_3_4
#exo_3_5
#exo_3_6
#exo_3_7

# exercices
#exo_4_1
#exo_4_2
#exo_4_3
#exo_4_4
#exo_4_5
#exo_4_6

# exercices
#exo_5_1
#exo_5_2



# tout supprimer
#deleteall

