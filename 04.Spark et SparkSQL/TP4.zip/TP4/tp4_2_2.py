#!/usr/bin/python
# -*- coding: utf-8 -*-

# lancement par spark-submit --py-files arbre.py tp4_2_2.py

from pyspark import SparkConf, SparkContext

# contexte d'exécution pour spark-submit
appName = "tp4_2_2"
conf = SparkConf().setAppName(appName) #.setMaster("spark://master:7077")
sc = SparkContext(conf=conf)

# http://spark.apache.org/docs/latest/api/python/pyspark.html#pyspark.RDD

# classe Arbre
from arbre import Arbre


## Question 2.2 : hauteur moyenne des arbres

# ouvrir le fichier
brut = sc.textFile("hdfs:/share/paris/arbres.csv")

# construire des Arbre à partir de chaque ligne
arbres = brut.map(lambda ligne: Arbre(ligne))

# récupérer seulement la hauteur des arbres (None si inconnue)
hauteurs = arbres.map(lambda arbre: arbre.hauteur())

# suppression des valeurs None dans la RDD
hauteurs_ok = hauteurs.filter(None)

# addition des valeurs (2 variantes)
#total = hauteurs_ok.reduce(lambda a,b: a+b)
total = hauteurs_ok.sum()

# nombre de valeurs pour la hauteur
nombre = hauteurs_ok.count()

# affichage de la moyenne
moyenne = total/nombre
print "hauteur moyenne des arbres (méthode 1) =",moyenne

# autre variante avec une fonction prédéfinie
moyenne = hauteurs_ok.mean()
print "hauteur moyenne des arbres (méthode 2) =",moyenne
