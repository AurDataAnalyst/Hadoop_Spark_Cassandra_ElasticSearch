#!/usr/bin/python
# -*- coding: utf-8 -*-

# classe pour traiter le fichier /share/paris/horodateurs-transactions.csv

import time

# retourne un timestamp (nombre de secondes depuis le 1er janvier 1970) d'une date/heure
def getTimestamp(datetimestr):
    try:
        # NB: il n'y a pas de prise en compte du TimeZone
        return time.mktime(time.strptime(datetimestr, "%d/%m/%Y %H:%M:%S"))
    except:
        return None


# chaque instance représente l'une des lignes du fichier
# n° horodateur;date horodateur;usager;moyen de paiement;montant carte;durée payée (h);début stationnement;fin stationnement
class Horodateur(object):

    # constructeur
    def __init__(self, ligne):
        # séparation de la ligne en champs
        self.champs = ligne.split(";")
        # en cas d'erreur ou la ligne des titres
        if len(self.champs) != 8 or self.champs[0] == u'n° horodateur':
            self.champs = None

    # affichage (equivalent de toString())
    def __str__(self):
        return "Horodateur[%s]" % ', '.join(self.champs)

    # retourne le numero ou None si on est sur la ligne de titre
    def numero(self):
        if not self.champs: return None
        return self.champs[0]

    # retourne la date de la transaction sous forme d'une chaîne
    def date(self):
        if not self.champs: return None
        return self.champs[1]

    # retourne le type d'usager
    def usager(self):
        if not self.champs: return None
        return self.champs[2]

    # retourne le moyen de paiement
    def moyen(self):
        if not self.champs: return None
        return self.champs[3]

    # retourne le montant de la transaction
    def montant(self):
        if not self.champs: return None
        try:
            return float(self.champs[4].replace(',','.'))
        except:
            return None

    # retourne le nombre d'heures payées
    def duree(self):
        if not self.champs: return None
        try:
            return float(self.champs[5].replace(',','.'))
        except:
            return None

    # retourne la date du début sous forme d'une chaîne
    def debut(self):
        if not self.champs: return None
        return self.champs[6]

    # retourne la date du début sous forme d'un timestamp
    def debutTS(self):
        if not self.champs: return None
        return getTimestamp(self.champs[6])

    # retourne la date de fin sous forme d'une chaîne
    def fin(self):
        if not self.champs: return None
        return self.champs[7]

    # retourne la date de fin sous forme d'un timestamp
    def finTS(self):
        if not self.champs: return None
        return getTimestamp(self.champs[7])
