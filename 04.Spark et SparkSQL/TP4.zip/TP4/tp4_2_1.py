#!/usr/bin/python
# -*- coding: utf-8 -*-

# lancement par spark-submit tp4_2_1.py

from pyspark import SparkConf, SparkContext

# contexte d'exécution pour spark-submit
appName = "tp4_2_1"
conf = SparkConf().setAppName(appName) #.setMaster("spark://master:7077")
sc = SparkContext(conf=conf)

# http://spark.apache.org/docs/latest/api/python/pyspark.html#pyspark.RDD



## Question 2.1 : nombre d'arbres

# ouvrir le fichier
brut = sc.textFile("hdfs:/share/paris/arbres.csv")

# affichage du nombre de lignes
nombre = brut.count()
print "nombre de lignes à traiter:", nombre
