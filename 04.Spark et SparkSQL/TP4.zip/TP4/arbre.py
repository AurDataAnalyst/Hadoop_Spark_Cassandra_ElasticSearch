#!/usr/bin/python
# -*- coding: utf-8 -*-

# classe pour traiter le fichier /share/paris/arbres.csv

# chaque instance représente l'une des lignes du fichier
class Arbre(object):

    # constructeur
    def __init__(self, ligne):
        # séparation de la ligne en champs
        self.champs = ligne.split(";")

    # affichage (equivalent de toString())
    def __str__(self):
        return "Arbre[%s]" % ', '.join(self.champs)

    # retourne le genre de l'arbre ou None si on est sur la ligne de titre
    def genre(self):
        if self.champs[2] == u'GENRE': return None
        return self.champs[2]

    # retourne la hauteur de l'arbre ou None si elle est absente/incorrecte
    def hauteur(self):
        try:
            return float(self.champs[6])
        except:
            return None
