#!/usr/bin/python
# -*- coding: utf-8 -*-

# lancement par spark-submit --py-files arbre.py tp4_2_3.py

from pyspark import SparkConf, SparkContext

# contexte d'exécution pour spark-submit
appName = "tp4_2_3"
conf = SparkConf().setAppName(appName).setMaster("spark://master:7077")
sc = SparkContext(conf=conf)

# http://spark.apache.org/docs/latest/api/python/pyspark.html#pyspark.RDD

# classe Arbre
from arbre import Arbre


## Question 2.3 : genre du plus grand arbre

# ouvrir le fichier
brut = sc.textFile("hdfs:/share/paris/arbres.csv")

# construire des Arbre à partir de chaque ligne
arbres = brut.map(lambda ligne: Arbre(ligne))

# construire des paires (hauteur, genre)
hauteurs_genres = arbres.map(lambda arbre: (arbre.hauteur(), arbre.genre()))

# suppression des paires dont la hauteur ou le genre sont inconnus
hauteurs_genres_ok = hauteurs_genres.filter(lambda (hauteur,genre): hauteur is not None and genre is not None)

# classement des paires par hauteur décroissante, deux possibilités
classement = hauteurs_genres_ok.sortByKey(ascending=False)
#classement = hauteurs_genres_ok.sortBy(lambda (hauteur,genre): hauteur, ascending=False)

# affichage de la première paire (= le plus grand arbre)
grand = classement.first()
print "plus grand arbre (méthode 1) =",grand

# autre méthode : max() sur la liste des paires => pas de tri
grand = hauteurs_genres_ok.max(lambda (hauteur,genre): hauteur)
print "plus grand arbre (méthode 2) =",grand
