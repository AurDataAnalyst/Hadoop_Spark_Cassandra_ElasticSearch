#!/usr/bin/python
# -*- coding: utf-8 -*-

## classe Station
# chaque instance représente l'une des lignes du fichier isd-history.txt
class Station(object):

    # constructeur
    def __init__(self, ligne):
        self.ligne = ligne

    def __str__(self):
        return "Station[usaf=%s]" % self.usaf()

    def usaf(self):
        return self.ligne[0:0+6]

    def nom(self):
        return self.ligne[13:13+29].strip()

    def pays(self):
        return self.ligne[43:43+2].strip()

    def latitude(self):
        try:
            return float(self.ligne[57:57+7])
        except:
            return None

    def longitude(self):
        try:
            return float(self.ligne[65:65+8])
        except:
            return None

    def altitude(self):
        try:
            return float(self.ligne[74:74+7])
        except:
            return None

    def annee_debut(self):
        try:
            return int(self.ligne[82:82+4])
        except:
            return None

    def annee_fin(self):
        try:
            return int(self.ligne[91:91+4])
        except:
            return None
