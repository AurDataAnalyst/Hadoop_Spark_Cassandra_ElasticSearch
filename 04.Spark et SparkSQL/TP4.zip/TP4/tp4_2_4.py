#!/usr/bin/python
# -*- coding: utf-8 -*-

# lancement par spark-submit --py-files arbre.py tp4_2_4.py

from pyspark import SparkConf, SparkContext

# contexte d'exécution pour spark-submit
appName = "tp4_2_4"
conf = SparkConf().setAppName(appName).setMaster("spark://master:7077")
sc = SparkContext(conf=conf)

# http://spark.apache.org/docs/latest/api/python/pyspark.html#pyspark.RDD

# classe Arbre
from arbre import Arbre


## Question 2.4 : nombre d'arbres de chaque genre

# ouvrir le fichier
brut = sc.textFile("hdfs:/share/paris/arbres.csv")

# construire des Arbre à partir de chaque ligne
arbres = brut.map(lambda ligne: Arbre(ligne))

# liste des genres d'arbres sans les None
genres = arbres.map(lambda arbre: arbre.genre()).filter(None)

# construction de paires (genre, 1)
genres_nombres = genres.map(lambda genre: (genre, 1))

# reduce genre par genre
genres_total = genres_nombres.reduceByKey(lambda a,b: a+b)

# affichage des cumuls par genre
print genres_total.collect()
