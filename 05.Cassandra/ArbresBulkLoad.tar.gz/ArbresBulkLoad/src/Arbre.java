
public abstract class Arbre
{
    /* Les champs sont
     *  0: Geo point
     *  1: ARRONDISSEMENT
     *  2: GENRE
     *  3: ESPECE
     *  4: FAMILLE
     *  5: ANNEE PLANTATION
     *  6: HAUTEUR
     *  7: CIRCONFERENCE
     *  8: ADRESSE
     *  9: NOM COMMUN
     * 10: VARIETE
     * 11: OBJECTID
     * 12: NOM_EV
     */
    static String[] champs;

    public static void fromLine(String ligne)
    {
        champs = ligne.split(";");
    }

    public static String getGeoPoint()
    {
        return champs[0];
    }

    public static Integer getArrondissement()
    {
        try {
            return Integer.parseInt(champs[1]);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static String getGenre()
    {
        return champs[2];
    }

    public static String getEspece()
    {
        return champs[3];
    }

    public static String getFamille()
    {
        return champs[4];
    }

    public static Integer getAnneePlantation()
    {
        try {
            return Integer.parseInt(champs[5]);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static Float getHauteur()
    {
        try {
            return Float.parseFloat(champs[6]);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static Float getCirconference()
    {
        try {
            return Float.parseFloat(champs[7]);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static String getAdresse()
    {
        return champs[8];
    }

    public static String getNomCommun()
    {
        return champs[9];
    }

    public static String getVariete()
    {
        return champs[10];
    }

    public static Integer getObjectID()
    {
        try {
            return Integer.parseInt(champs[11]);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static String getNomEV()
    {
        return champs[12];
    }
}
