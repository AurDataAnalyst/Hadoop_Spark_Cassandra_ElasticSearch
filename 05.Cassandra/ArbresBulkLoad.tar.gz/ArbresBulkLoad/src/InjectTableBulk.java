
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

import org.apache.cassandra.config.Config;
import org.apache.cassandra.dht.Murmur3Partitioner;
import org.apache.cassandra.io.sstable.CQLSSTableWriter;

/* tiré de https://github.com/yukim/cassandra-bulkload-example/ */

public class InjectTableBulk
{
    // keyspace et nom de la table (donnent également le nom des dossiers créés)
    private static final String KEYSPACE = "undefined"; // FIXME
    private static final String TABLE_NAME = "arbres";

    // requête de création de la table
    private static final String CREATE_STMT =
        "CREATE TABLE "+KEYSPACE+"."+TABLE_NAME+" (" +
        "    geopoint            text, " +
        "    arrondissement      int,  " +
        "    genre               text, " +
        "    espece              text, " +
        "    famille             text, " +
        "    annee_plantation    int,  " +
        "    hauteur             float," +
        "    circonference       float," +
        "    adresse             text, " +
        "    nom_commun          text, " +
        "    variete             text, " +
        "    objectid            int,  " +
        "    nom_ev              text, " +
        "    PRIMARY KEY (objectid))";

    // requête d'insertion dans la table
    private static final String INSERT_STMT =
        "INSERT INTO "+KEYSPACE+"."+TABLE_NAME+" (" +
        "    geopoint         , " +
        "    arrondissement   , " +
        "    genre            , " +
        "    espece           , " +
        "    famille          , " +
        "    annee_plantation , " +
        "    hauteur          , " +
        "    circonference    , " +
        "    adresse          , " +
        "    nom_commun       , " +
        "    variete          , " +
        "    objectid         , " +
        "    nom_ev)" +
        " VALUES (" +
        "    ?, " +
        "    ?, " +
        "    ?, " +
        "    ?, " +
        "    ?, " +
        "    ?, " +
        "    ?, " +
        "    ?, " +
        "    ?, " +
        "    ?, " +
        "    ?, " +
        "    ?, " +
        "    ?)";

    // nombre de n-uplets insérés en une fois, ft de la ram disponible
    private static final int MAX_TUPLES = 40000;


    public static void main(String[] args) throws Exception
    {
        // lancement du chronomètre
        Long initTime = System.currentTimeMillis();

        // vérification et extraction des paramètres
        if (args.length != 1) {
            System.err.println("Usage: cat <fichier.csv> | "+InjectTableBulk.class.getSimpleName()+" <outputdir>");
            System.exit(-1);
        }
        String outputpath = args[0];
        int foldernumber = 0;

        // magic but deprecated !!
        Config.setClientMode(true);

        // colonnes du fichier CSV
        List<Object> row = new ArrayList<>(13);

        // le writer sera créé à la première ligne du fichier
        CQLSSTableWriter writer = null;

        // ouvrir stdin (le fichier CSV arrive par un tube)
        try (
            // syntaxe java 8 avec les closeable
            InputStreamReader isr = new InputStreamReader(System.in);
            BufferedReader br = new BufferedReader(isr)
        ) {

            // lire ligne par ligne
            String line;
            int linenumber = 0; // numéro de la ligne dans le fichier d'entrée
            int linecount = -1; // nombre de lignes écrites par le writer, -1 pour forcer la création d'un writer à la première ligne
            while ((line = br.readLine()) != null) {

                // si on dépasse la limite, forcer la création d'un nouveau writer
                if (linecount >= MAX_TUPLES) {
                    writer.close();
                    linecount = -1;
                }
                // faut-il créer un nouveau writer ?
                if (linecount < 0) {
                    // créer un dossier /data/tmp/keyspace/numéro/keyspace/table
                    File outputDir = new File(String.format("%s/%05d/%s/%s",
                            outputpath, foldernumber, KEYSPACE, TABLE_NAME));
                    if (!outputDir.exists() && !outputDir.mkdirs()) {
                        throw new RuntimeException("Cannot create output directory: " + outputDir);
                    }
                    foldernumber++;

                    // préparer le writer
                    CQLSSTableWriter.Builder builder = CQLSSTableWriter.builder();
                    builder.inDirectory(outputDir)  // dossier de sortie
                           .forTable(CREATE_STMT)   // schéma
                           .using(INSERT_STMT)      // requête d'insertion préparée
                           .withPartitioner(new Murmur3Partitioner());

                    // créer le writer
                    writer = builder.build();
                    linecount = 0;
                }

                // une ligne lue de plus
                linenumber++;
                // afficher l'avancement de temps en temps (cas de fichiers énormes)
                if (linenumber%100000 == 0) System.out.println("ligne "+linenumber);

                // ignorer la première ligne (ligne de titre)
                if (linenumber == 1) continue;

                // toute erreur fait ignorer la ligne
                try {

                    // séparer la ligne en champs
                    Arbre.fromLine(line);

                    // fournir les champs dans le bon ordre et du bon type
                    row.clear();
                    row.add(Arbre.getGeoPoint());
                    row.add(Arbre.getArrondissement());
                    row.add(Arbre.getGenre());
                    row.add(Arbre.getEspece());
                    row.add(Arbre.getFamille());
                    row.add(Arbre.getAnneePlantation());
                    row.add(Arbre.getHauteur());
                    row.add(Arbre.getCirconference());
                    row.add(Arbre.getAdresse());
                    row.add(Arbre.getNomCommun());
                    row.add(Arbre.getVariete());
                    row.add(Arbre.getObjectID());
                    row.add(Arbre.getNomEV());

                    // ajouter la ligne
                    writer.addRow(row);
                    linecount++;

                } catch (Exception e) {
                    // si vous êtes totalement perplexe...
                    // System.err.println(e);
                }
            }

            // c'est fini
            System.out.println("ligne "+linenumber+" finale");
            System.out.println("writer "+foldernumber+", compte "+linecount);

        } catch (IOException e) {
            e.printStackTrace();
        }
        writer.close();

        // temps passé
        Long endTime = System.currentTimeMillis();
        System.out.println("Total Duration seconds: " + ((endTime-initTime)/1000L));

        System.exit(0);
    }
}
