import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.*;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.filter.*;
import org.apache.hadoop.hbase.filter.CompareFilter.*;
import org.apache.hadoop.hbase.util.*;
import java.io.IOException;
import java.util.Map;
import java.util.ArrayList;


class DemoHBase
{
    private static void CreerTable(HBaseAdmin admin, String nomtable, String... familles) throws IOException
    {
        TableName tn = TableName.valueOf(nomtable);
        if (admin.tableExists(tn)) {
            System.err.println("La table "+nomtable+" existe déjà");
            return;
        }
        HTableDescriptor htd = new HTableDescriptor(tn);
        for (String famille: familles) {
            htd.addFamily(new HColumnDescriptor(famille));
        }
        admin.createTable(htd);
    }


    private static void SupprimerTable(HBaseAdmin admin, String nomtable) throws IOException
    {
        TableName tn = TableName.valueOf(nomtable);
        if (admin.tableExists(tn)) {
            admin.disableTable(tn);
            admin.deleteTable(tn);
        }
    }


    private static void AjouterValeur(Configuration config,
            String nomtable, String id, String fam, String col, String val) throws IOException
    {
        HTable table = new HTable(config, nomtable);
        try {
            // construire un Put
            final byte[] rawid = Bytes.toBytes(id);
            Put action = new Put(rawid);
            final byte[] rawfam = Bytes.toBytes(fam);
            final byte[] rawcol = Bytes.toBytes(col);
            final byte[] rawval = Bytes.toBytes(val);
            action.add(rawfam, rawcol, rawval);
            // effectuer l'ajout dans la table
            table.put(action);
        } finally {
            table.close();
        }
    }


    private static void AjouterValeur(Configuration config,
            String nomtable, String id, String fam, String col, int val) throws IOException
    {
        HTable table = new HTable(config, nomtable);
        try {
            // construire un Put
            final byte[] rawid = Bytes.toBytes(id);
            Put action = new Put(rawid);
            final byte[] rawfam = Bytes.toBytes(fam);
            final byte[] rawcol = Bytes.toBytes(col);
            final byte[] rawval = Bytes.toBytes(val);
            action.add(rawfam, rawcol, rawval);
            // effectuer l'ajout dans la table
            table.put(action);
        } finally {
            table.close();
        }
    }

    private static void AjouterAnnuaire(Configuration config,
            String nomtable, String id,
            String nom, String prenom, int age, String email) throws IOException
    {
        HTable table = new HTable(config, nomtable);
        try {
            ArrayList<Put> ajouts = new ArrayList<>();
            final byte[] rawid = Bytes.toBytes(id);
            // construire un Put pour le nom
            Put putnom = new Put(rawid);
            putnom.add(Bytes.toBytes("pers"), Bytes.toBytes("nom"), Bytes.toBytes(nom));
            ajouts.add(putnom);
            // construire un Put pour le prénom
            Put putprenom = new Put(rawid);
            putprenom.add(Bytes.toBytes("pers"), Bytes.toBytes("prenom"), Bytes.toBytes(prenom));
            ajouts.add(putprenom);
            // construire un Put pour l'age
            Put putage = new Put(rawid);
            putage.add(Bytes.toBytes("pers"), Bytes.toBytes("age"), Bytes.toBytes(age));
            ajouts.add(putage);
            // construire un Put pour l'email
            Put putmail = new Put(rawid);
            putmail.add(Bytes.toBytes("contact"), Bytes.toBytes("mail"), Bytes.toBytes(email));
            ajouts.add(putmail);

            // effectuer les ajouts dans la table
            table.put(ajouts);
        } finally {
            table.close();
        }
    }



    private static void AfficherNuplet(Configuration config, String nomtable, String id) throws IOException
    {
        System.out.println("AfficherNuplet("+nomtable+", "+id+")");
        final byte[] rawid = Bytes.toBytes(id);
        Get action = new Get(rawid);
        // appliquer le get à la table
        HTable table = new HTable(config, nomtable);
        try {
            Result result = table.get(action);
            AfficherResult(result);
        } finally { table.close(); }
    }


    private static void AfficherResult(Result result)
    {
        if (result == null || result.isEmpty()) return;
        for (Cell cell: result.listCells()) {
            AfficherCell(cell);
        }
    }


    private static void AfficherCell(Cell cell)
    {
        // extraire la famille
        String fam = Bytes.toString(cell.getFamilyArray(), cell.getFamilyOffset(), cell.getFamilyLength());
        // extraire la colonne (qualifier)
        String col = Bytes.toString(cell.getQualifierArray(), cell.getQualifierOffset(), cell.getQualifierLength());
        // extraire la valeur (attention, ce n'est pas forcément une chaîne, mais comment savoir dans le cas général ???)
//        if ("age".equals(col)) {
//            int val = Bytes.toInt(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength());
//            System.out.println(fam+":"+col+" = (int)"+val);
//        } else {
            String val = Bytes.toString(cell.getValueArray(), cell.getValueOffset(), cell.getValueLength());
            System.out.println("\t"+fam+":"+col+" = "+val);
//        }
    }


    private static void ChercherJeunes(Configuration config, String nomtable) throws IOException
    {
        System.out.println("ChercherJeunes("+nomtable+")");
        // créer un "parcoureur"
        Scan action = new Scan();

        // lui ajouter une conjonction de filtres

        // on cherche un age <= 30
        final byte[] rawfam = Bytes.toBytes("pers");
        final byte[] rawcol = Bytes.toBytes("age");
        final byte[] rawval = Bytes.toBytes(30);
        BinaryComparator binval = new BinaryComparator(rawval);
        SingleColumnValueFilter filtre1 = new SingleColumnValueFilter(rawfam, rawcol, CompareOp.LESS_OR_EQUAL, binval);

        // on cherche la famille pers
        BinaryComparator binfam = new BinaryComparator(rawfam);
        FamilyFilter filtre2 = new FamilyFilter(CompareOp.EQUAL, binfam);

        // on cherche la colonne nom
        BinaryComparator binnom = new BinaryComparator(Bytes.toBytes("nom"));
        QualifierFilter filtre3 = new QualifierFilter(CompareOp.EQUAL, binnom);

        // conjonction des trois filtres
        FilterList conjonction = new FilterList(FilterList.Operator.MUST_PASS_ALL, filtre1, filtre2, filtre3);
        action.setFilter(conjonction);

        // lancer le scan
        HTable table = new HTable(config, nomtable);
        ResultScanner results = table.getScanner(action);
        for (Result result: results) {
            AfficherResult(result);
        }
    }


    public static void main(String[] args)
    {
        // nom de la table HBase à créer
        Map<String, String> env = System.getenv();
        String NomTable = env.get("LOGNAME") + "Annuaire";

        try {
            Configuration config = HBaseConfiguration.create();
            HBaseAdmin admin = new HBaseAdmin(config);
            try {
                // créer l'annuaire de téléphone
                CreerTable(admin, NomTable, "pers", "contact");

                // ajouter quelques données
                AjouterValeur(config, NomTable, "bornibus", "pers", "nom", "Bornibus");
                AjouterValeur(config, NomTable, "bornibus", "pers", "age", 21);
                AjouterValeur(config, NomTable, "bornibus", "contact", "mail", "bornibus@gouv.fr");

                AjouterValeur(config, NomTable, "bvapor", "pers", "nom", "Vapor");
                AjouterValeur(config, NomTable, "bvapor", "pers", "prenom", "Bark");
                AjouterValeur(config, NomTable, "bvapor", "pers", "age", 347);
                AjouterValeur(config, NomTable, "bvapor", "contact", "mail", "bark@blk.str");

                AjouterAnnuaire(config, NomTable, "billb", "Boquet", "Bill", 27, "bb@iut.fr");

                // afficher un n-uplet
                AfficherNuplet(config, NomTable, "bvapor");

                // rechercher des valeurs
                ChercherJeunes(config, NomTable);

                // supprimer la table
                SupprimerTable(admin, NomTable);

            } finally {
                admin.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
